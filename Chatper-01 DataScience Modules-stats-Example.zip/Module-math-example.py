import math

print(math.pi)

print(math.pow(2,3))
print(math.sqrt(9))

print(math.factorial(10))

print(math.sin(90))
print(math.cos(90))

##random: generate the random number
import random

#return random value from given range 
print(random.randint(1,10))
print(random.randint(1,10))
print(random.randint(1,10))
print(random.randint(1,10))
print(random.randint(1000,9999))


#default between 0 to 1
print(random.random())

print(random.random()*1000)



